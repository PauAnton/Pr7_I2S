This is opusfile from Xiph, modified to build under Arduino by <earlephilhower@yahoo.com> and adjusted to work with AudioFileSources,

Original license/etc. unchanged.
